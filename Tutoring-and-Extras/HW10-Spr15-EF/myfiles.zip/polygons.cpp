#include "polygons.h"
#include "utilities.h"

Polygon::Polygon(std::string _name_, std::vector<Point> _points_){
	name = _name_;
	points = _points_;
	//making the vectors of sides and angles
	for(int i = 0; i < points.size(); i++){
		//calculating sides(Vectors)
		if(i == points.size()-1){
			sides.push_back(Vector(points[i], points[0]));
		}else{
			sides.push_back(Vector(points[i], points[i+1]));
		}
		//calculating angles(doubles)
		if(i == 0){
			angles.push_back(Angle(points[points.size()-1], points[i], points[i+1]));
		}else if(i == points.size()-1){
			angles.push_back(Angle(points[i-1], points[i], points[0]));
		}else{
			angles.push_back(Angle(points[i-1], points[i], points[i+1]));
		}
	}
}

bool Polygon::HasAllEqualSides(){
	double len = sides[0].Length();
	for(int i = 1; i < sides.size(); i++){
		if(!EqualSides(sides[i].Length(),len)) return false;
	}
	return true;
}

bool Polygon::HasAllEqualAngles(){
	double ang = angles[0];
	for(int i = 1; i < angles.size(); i++){
		if(!EqualAngles(ang,angles[i])) return false;
	}
	return true;
}

bool Polygon::HasARightAngle(){
	for(int i = 0; i < angles.size(); i++){
		if(RightAngle(angles[i])) return true;
	}
	return false;
}

bool Polygon::HasAnObtuseAngle(){
	for(int i = 0; i < angles.size(); i++){
		if(ObtuseAngle(angles[i])) return true;
	}
	return false;
}

bool Polygon::HasAnAcuteAngle(){
	for(int i = 0; i < angles.size(); i++){
		if(AcuteAngle(angles[i])) return true;
	}
	return false;
}

bool Polygon::IsConvex(){
	for(int i = 0; i < angles.size(); i++){
		if(ReflexAngle(angles[i])) return false;
	}
	return true;
}

bool Polygon::IsConcave(){
	for(int i = 0; i < angles.size(); i++){
		if(ReflexAngle(angles[i])) return true;
	}
	return false;
}

//Triangles
Triangle::Triangle(std::string _name_, std::vector<Point> _points_) : Polygon(_name_, _points_){
	if(_points_.size() != 3) throw 69;
}

RightTriangle::RightTriangle(std::string _name_, std::vector<Point> _points_) : Triangle(_name_, _points_){
	//checks if theres a right angle
	double biggest = 0;
	for(int i = 0; i < angles.size(); i++){
		if(angles[i] > biggest) biggest = angles[i];
	}
	if(!RightAngle(biggest)) throw 69;
}

IsoscelesTriangle::IsoscelesTriangle(std::string _name_, std::vector<Point> _points_) : Triangle(_name_, _points_){
	//if any two pairs of the sides are not equal
	if(!(EqualSides(sides[1].Length(),sides[0].Length()) || EqualSides(sides[1].Length(), sides[2].Length()) || EqualSides(sides[0].Length(), sides[2].Length()))){
		throw 69;
	}
}

ObtuseTriangle::ObtuseTriangle(std::string _name_, std::vector<Point> _points_) : Triangle(_name_, _points_){
	//checks if theres an obtuse angle
	double biggest = 0;
	for(int i = 0; i < angles[i]; i++){
		if(angles[i] > biggest) biggest = angles[i];
	}
	if(!ObtuseAngle(biggest)) throw 69;
}

IsoscelesObtuseTriangle::IsoscelesObtuseTriangle(std::string _name_, std::vector<Point> _points_) : Triangle(_name_, _points_), IsoscelesTriangle(_name_, _points_), ObtuseTriangle(_name_, _points_){}

IsoscelesRightTriangle::IsoscelesRightTriangle(std::string _name_, std::vector<Point> _points_) : Triangle(_name_, _points_), IsoscelesTriangle(_name_, _points_), RightTriangle(_name_, _points_){}

EquilateralTriangle::EquilateralTriangle(std::string _name_, std::vector<Point> _points_) : Triangle(_name_, _points_), IsoscelesTriangle(_name_, _points_){
	//if all the sides do not equal each other
	if(!(EqualSides(sides[1].Length(),sides[0].Length()) && EqualSides(sides[1].Length(), sides[2].Length()) && EqualSides(sides[0].Length(), sides[2].Length()))){
		throw 69;
	}
}

//Quadrilaterals
Quadrilateral::Quadrilateral(std::string _name_, std::vector<Point> _points_) : Polygon(_name_, _points_){
	if(points.size() != 4) throw 69;
}

Arrow::Arrow(std::string _name_, std::vector<Point> _points_) : Quadrilateral(_name_, _points_){
	//check for reflex angle
	double biggest = 0;
	for(int i = 0; i < angles.size(); i++){
		if(angles[i] > biggest) biggest = angles[i];
	}
	if(!ReflexAngle(biggest)) throw 69;
	//check for pair of equal adjacent sides
	double big = 0;
	int bigIndex = 0;
	for(int i = 0; i < sides.size(); i++){
		if(sides[i].Length() > big){
			bigIndex = i;
			big = sides[i].Length();
		}
	}
	if(bigIndex == sides.size()-1){
		if(!(EqualSides(sides[bigIndex].Length(),sides[0].Length()) || EqualSides(sides[bigIndex].Length(), sides[bigIndex-1].Length()))) throw 69;
	}else{
		if(!(EqualSides(sides[bigIndex].Length(),sides[bigIndex+1].Length()) || EqualSides(sides[bigIndex].Length(), sides[bigIndex-1].Length()))) throw 69;
	}
}

Trapezoid::Trapezoid(std::string _name_, std::vector<Point> _points_) : Quadrilateral(_name_, _points_){
	//check for reflex angle
	double biggest = 0;
	for(int i = 0; i < angles.size(); i++){
		if(angles[i] > biggest) biggest = angles[i];
	}
	if(ReflexAngle(biggest)) throw 69;
	//check for a pair of parallel sides
	if(!(Parallel(sides[0], sides[2]) || Parallel(sides[1],sides[3]))) throw 69;
}

Kite::Kite(std::string _name_, std::vector<Point> _points_) : Quadrilateral(_name_, _points_){
	for(int i = 0; i < sides.size(); i++){
		if(i == 0){
			if(!(EqualSides(sides[i].Length(), sides[3].Length()) || EqualSides(sides[i].Length(), sides[i+1].Length()))) throw 69;
		}else{
			if(!(EqualSides(sides[i].Length(), sides[i+1].Length()) || EqualSides(sides[i].Length(), sides[i-1].Length()))) throw 69;
		}
	}
}

IsoscelesTrapezoid::IsoscelesTrapezoid(std::string _name_, std::vector<Point> _points_) : Quadrilateral(_name_, _points_), Trapezoid(_name_, _points_){
	//check for 2 pairs of equal angles
	if(EqualAngles(angles[0], angles[1])){
		if(!EqualAngles(angles[2], angles[3])) throw 69;
	}else if(EqualAngles(angles[0], angles[3])){
		if(!EqualAngles(angles[1], angles[2])) throw 69;
	}
}

Parallelogram::Parallelogram(std::string _name_, std::vector<Point> _points_) : Quadrilateral(_name_, _points_), Trapezoid(_name_, _points_){
	//check for 2 pairs of equal angles
	if(!(EqualAngles(angles[0], angles[2]) && EqualAngles(angles[1], angles[3]))) throw 69;
}

Rectangle::Rectangle(std::string _name_, std::vector<Point> _points_) : Quadrilateral(_name_, _points_), Trapezoid(_name_, _points_), IsoscelesTrapezoid(_name_, _points_), Parallelogram(_name_, _points_){
	//check for 4 right angles
	for(int i = 0; i < angles.size(); i++){
		if(!RightAngle(angles[i])) throw 69;
	}
}

Rhombus::Rhombus(std::string _name_, std::vector<Point> _points_) : Quadrilateral(_name_, _points_), Trapezoid(_name_, _points_), Kite(_name_, _points_), Parallelogram(_name_, _points_){
	//check for 4 equal sides
	for(int i = 0; i < sides.size(); i++){
		if(i == sides.size() - 1){
			if(!EqualSides(sides[i].Length(), sides[0].Length())) throw 69;
		}else{
			if(!EqualSides(sides[i].Length(), sides[i+1].Length())) throw 69;
		}
	}
}

Square::Square(std::string _name_, std::vector<Point> _points_) : Quadrilateral(_name_, _points_), Trapezoid(_name_, _points_), Parallelogram(_name_, _points_), Rectangle(_name_, _points_), Rhombus(_name_, _points_){}