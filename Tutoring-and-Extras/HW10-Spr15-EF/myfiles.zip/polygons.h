#ifndef POLY
#define POLY

#include <vector>
#include <string>
#include "utilities.h"

class Polygon{
public:
	//consructor
	Polygon(std::string _name_, std::vector<Point> _points_);
	//accessors
	std::string getName() const{return name;}
	virtual bool HasAllEqualSides();
	virtual bool HasAllEqualAngles();
	virtual bool HasARightAngle();
	virtual bool HasAnObtuseAngle();
	virtual bool HasAnAcuteAngle();
	virtual bool IsConvex();
	virtual bool IsConcave();
protected:
	std::string name;
	std::vector<Point> points;
	std::vector<Vector> sides;
	std::vector<double> angles;
};

//==========================================================
//    THREE-SIDED SHAPES
//==========================================================

class Triangle : public Polygon{
public:
	//constructor
	Triangle(std::string _name_, std::vector<Point> _points_);
	//changing an accessor
	bool HasAnAcuteAngle(){return true;}
};

class RightTriangle : public virtual Triangle{
public:	
	//constructor
	RightTriangle(std::string _name_, std::vector<Point> _points_);
	//changing an accessor
	bool HasARightAngle(){return true;}
	bool HasAnObtuseAngle(){return false;}
};

class IsoscelesTriangle : public virtual Triangle{
public:
	//constructor
	IsoscelesTriangle(std::string _name_, std::vector<Point> _points_);
	//no accessors to change
};

class ObtuseTriangle : public virtual Triangle{
public:
	//constructor
	ObtuseTriangle(std::string _name_, std::vector<Point> _points_);
	//changing some accessors
	bool HasAnObtuseAngle(){return true;}
	bool HasARightAngle(){return false;}
};

class IsoscelesObtuseTriangle : public IsoscelesTriangle, public ObtuseTriangle{
public:
	//constructor
	IsoscelesObtuseTriangle(std::string _name_, std::vector<Point> _points_);
	//no accessors to change
};

class IsoscelesRightTriangle : public RightTriangle, public IsoscelesTriangle{
public:
	//constructor
	IsoscelesRightTriangle(std::string _name_, std::vector<Point> _points_);
	//no accessors to change
};

class EquilateralTriangle : public IsoscelesTriangle{
public:	
	//constructor
	EquilateralTriangle(std::string _name_, std::vector<Point> _points_);
	//changing some accessors
	bool HasAllEqualSides(){return true;}
	bool HasAllEqualAngles(){return true;}
	bool HasARightAngle(){return false;}
	bool HasAnObtuseAngle(){return false;}
	bool HasAnAcuteAngle(){return true;}
};

//==========================================================
//    FOUR-SIDED SHAPES
//==========================================================

class Quadrilateral : public Polygon{
public:	
	//constructor
	Quadrilateral(std::string _name_, std::vector<Point> _points_);
	//no accessors to change
};

class Arrow : public Quadrilateral{
public:	
	//constructor
	Arrow(std::string _name_, std::vector<Point> _points_);
	//changing some accessors
	bool HasAnObtuseAngle(){return true;}
	bool HasAnAcuteAngle(){return true;}
	bool isConvex(){return false;}
	bool isConcave(){return true;}
};

class Trapezoid : public virtual Quadrilateral{
public:
	//constructor
	Trapezoid(std::string _name_, std::vector<Point> _points_);
	//no accessors to change
};

class Kite : public virtual Quadrilateral{
public:
	//constructor
	Kite(std::string _name_, std::vector<Point> _points_);
	//no accessors to change
};

class IsoscelesTrapezoid : public virtual Trapezoid{
public:
	//constructor
	IsoscelesTrapezoid(std::string _name_, std::vector<Point> _points_);
	//no accessors to change
};

class Parallelogram : public virtual Trapezoid{
public:
	//constructor
	Parallelogram(std::string _name_, std::vector<Point> _points_);
	//no accessors to change
};

class Rectangle : public IsoscelesTrapezoid, public virtual Parallelogram{
public:
	//constructor
	Rectangle(std::string _name_, std::vector<Point> _points_);
	//changing some accessors
	bool HasAllEqualAngles(){return true;}
	bool HasARightAngle(){return true;}
	bool HasAnObtuseAngle(){return false;}
	bool HasAnAcuteAngle(){return false;}
};

class Rhombus : public virtual Parallelogram, public Kite{
public:
	//constructor
	Rhombus(std::string _name_, std::vector<Point> _points_);
	//changing some accessors
	bool HasAllEqualSides(){return true;}
};

class Square : public Rhombus, public Rectangle{
public:
	//constructor
	Square(std::string _name_, std::vector<Point> _points_);
	//no accessors to change
};

#endif