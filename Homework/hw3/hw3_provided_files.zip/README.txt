HOMEWORK 3: JAGGED ARRAY


NAME:  < insert name >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >



ORDER NOTATION:
For each function, for each version (packed vs. unpacked).  
b = the number of bins
e = the number of elements
k = the number of elements

numElements
 unpacked:
 packed:

numBins
 unpacked:
 packed:

numElementsInBin
 unpacked:
 packed:

getElement
 unpacked:
 packed:

isPacked
 unpacked:
 packed:

clear
 unpacked:
 packed:

addElement
 unpacked:
 packed:

removeElement
 unpacked:
 packed:

pack
 unpacked:
 packed:

unpack
 unpacked:
 packed:

print 
 unpacked:
 packed:

constructor w/ integer argument
 unpacked:
 packed:

copy constructor
 unpacked:
 packed:

destructor
 unpacked:
 packed:

assignment operator
 unpacked:
 packed:




MISC. COMMENTS TO GRADER:  
(optional, please be concise!)


