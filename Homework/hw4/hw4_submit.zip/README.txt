HOMEWORK 4: PREFERENCE LISTS


NAME:  Sam Saks-Fithian


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

www.cplusplus.com

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  5



ORDER NOTATION:
m schools, s slots per school, r rankings of students by each school, n students, p preferences of schools by each student

add_school — nr + m

insert_student_into_school_preference_list — mr

print_school_preferences — mr

add_student — mp + n

remove_school_from_student_preference_list — np

print_student_preferences — np

perform_matching — nm^2

print_school_enrollments — ms

print_student_decisions — n



MISC. COMMENTS TO GRADER:  
Optional, please be concise!


