HOMEWORK 9: PERFECT HASHING


NAME:  Sam Saks-Fithian


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

www.cplusplus.com (various)
http://www.cprogramming.com/tutorial/references.html
http://www.cplusplus.com/forum/general/59383/

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  10



SUMMARY OF RESULTS: 
Summarize your results on the provided examples.  Were you able to
construct a perfect hash function?  If not, how close did you get (how
many collisions)?  If yes, what was the smallest perfect hash you were
able to construct for the different examples?  What was your
compression ratio?  Did you make any additional test cases?

Yes, I was.
Chair - s_hash: 3, s_offset: 2, compression ratio: 0.58
Car - s_hash: 25, s_offset: 14, compression ratio: 0.37
Lightbulb - s_hash: 41, s_offset: 22, compression ratio: 0.15


OFFSET SEARCH FOR EXTRA CREDIT:
If you implemented a search strategy instead of or in addition to the
greedy method from the paper, describe it here.



MISC. COMMENTS TO GRADER:  
Optional, please be concise!






