HOMEWORK 2: BOWLING CLASSES


NAME:  Sam Saks-Fithian


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

http://msdn.microsoft.com/en-us/library/37zc9d2w.aspx
http://www.cplusplus.com/  (various)
https://www.cs.rpi.edu/academics/courses/fall14/csci1200/other_information.php

Doug (ALAC Tutor)

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  7ish



DESCRIPTION OF YOUR CREATIVE STATISTIC:
Please be concise!

Counts and keeps track of the extra/bonus points each player has earned through spares and strikes.


MISC. COMMENTS TO GRADER:  
Optional, please be concise!


