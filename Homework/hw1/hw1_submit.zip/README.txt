HOMEWORK 1: MOIRE STRINGS


NAME:  Sam Saks-Fithian


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

https://www.cs.rpi.edu/academics/courses/fall14/csci1200/other_information.php
http://www.cplusplus.com/articles/DEN36Up4/
http://cs.stmarys.ca/~porter/csc/ref/c_cpp_strings.html

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  5ish



EXTRA CREDIT SHAPES:
Describe your new shapes and your implementation strategy.  Please be
concise!  Paste in examples of command lines & output for your new shapes.

Made a diamond using similar input as the isosceles triangle, just going in then out halfway.

MISC. COMMENTS TO GRADER:  
Optional, please be concise!


